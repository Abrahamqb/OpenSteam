import os
import zipfile
import threading
from io import BytesIO
from typing import Dict, Any, List, Optional

import PluginUtils
from http_client import get_global_client
from steam_utils import get_stplug_in_path

logger = PluginUtils.Logger()

def _save_lua_bytes(dest_dir: str, appid: int, content: bytes) -> str:
    os.makedirs(dest_dir, exist_ok=True)
    dst = os.path.join(dest_dir, f"{appid}.lua")
    with open(dst, "wb") as f:
        f.write(content)
    return dst

def _extract_only_target_lua_from_zip_bytes(dest_dir: str, appid: int, zip_bytes: bytes) -> str:
    target = f"{appid}.lua"
    with zipfile.ZipFile(BytesIO(zip_bytes), 'r') as z:
        names = z.namelist()
        lower = [n.lower() for n in names]
        tlower = target.lower()
        wanted_name: Optional[str] = None
        for i, n in enumerate(lower):
            if n.endswith('/' + tlower) or n == tlower:
                wanted_name = names[i]; break
        if not wanted_name:
            raise RuntimeError(f"Zip missing expected LUA: {target}")
        data = z.read(wanted_name)
        return _save_lua_bytes(dest_dir, appid, data)

def _content_type_is_lua(ctype: str) -> bool:
    c = (ctype or '').split(';')[0].strip().lower()
    return c in ('text/plain', 'text/x-lua', 'application/octet-stream')

class KerneluaManager:
    def __init__(self, backend_path: str):
        self.backend_path = backend_path
        self._download_state: Dict[int, Dict[str, Any]] = {}
        self._download_lock = threading.Lock()
        self._api_key = None

    def set_api_key(self, api_key: str):
        self._api_key = api_key

    def get_api_key(self):
        return self._api_key

    def _set_download_state(self, appid: int, update: Dict[str, Any]) -> None:
        with self._download_lock:
            state = self._download_state.get(appid, {})
            state.update(update)
            self._download_state[appid] = state

    def _get_download_state(self, appid: int) -> Dict[str, Any]:
        with self._download_lock:
            return self._download_state.get(appid, {}).copy()

    def get_download_status(self, appid: int) -> Dict[str, Any]:
        state = self._get_download_state(appid)
        return {'success': True, 'state': state}

    def _download_backend(self, appid: int) -> None:
        try:
            self._set_download_state(appid, {
                'status': 'checking',
                'currentApi': 'kernelos',
                'bytesRead': 0,
                'totalBytes': 0,
                'endpoint': 'kernelos'
            })
            client = get_global_client()
            if not client:
                raise Exception("Failed to get HTTP client")
        except Exception as e:
            logger.error(f"kernelua: setup failed: {e}")
            self._set_download_state(appid, {'status': 'failed', 'error': f'Setup failed: {str(e)}'})
            return

        try:
            from api_manager import APIManager
            api_manager = APIManager(self.backend_path)
            res = api_manager.get_signed_download_url(appid)
            if not res.get('success') or not res.get('url'):
                raise RuntimeError(res.get('error', 'No signed URL'))
            download_url = res['url']
        except Exception as e:
            logger.error(f"kernelua: signed link error: {e}")
            self._set_download_state(appid, {'status': 'failed', 'error': f'Generator error: {str(e)}'})
            return

        try:
            self._set_download_state(appid, {'status': 'downloading', 'endpoint': 'kernelos', 'bytesRead': 0, 'totalBytes': 0})
            status, headers, body = client.raw_get(download_url)

            if status == 410:
                self._set_download_state(appid, {'status': 'failed', 'error': 'Expired link: regenerate'}); return
            if status == 403:
                self._set_download_state(appid, {'status': 'failed', 'error': 'Access denied / invalid signature'}); return
            if status == 404:
                self._set_download_state(appid, {'status': 'failed', 'error': 'File not found on server'}); return
            if status < 200 or status >= 300:
                self._set_download_state(appid, {'status': 'failed', 'error': f'HTTP {status}'}); return
            if not isinstance(body, (bytes, bytearray)) or len(body) == 0:
                self._set_download_state(appid, {'status': 'failed', 'error': 'Empty response'}); return

            ctype = headers.get('Content-Type', '')
            clen = headers.get('Content-Length', '')
            try:
                clen_int = int(clen) if clen and str(clen).isdigit() else len(body)
            except Exception:
                clen_int = len(body)
            logger.log(f"kernelua: HTTP {status}, {len(body)} bytes (CL={clen}), Content-Type={ctype}")

            self._set_download_state(appid, {'status': 'processing', 'bytesRead': len(body), 'totalBytes': clen_int, 'contentType': ctype})

            target_dir = get_stplug_in_path()
            try:
                if _content_type_is_lua(ctype):
                    dst = _save_lua_bytes(target_dir, appid, body)
                else:
                    try:
                        dst = _extract_only_target_lua_from_zip_bytes(target_dir, appid, body)
                    except zipfile.BadZipFile:
                        snippet = body[:512].lower()
                        if snippet.startswith(b'--') or b'registry' in snippet or b'steam' in snippet:
                            dst = _save_lua_bytes(target_dir, appid, body)
                        else:
                            raise
                self._set_download_state(appid, {
                    'status': 'done',
                    'success': True,
                    'api': 'kernelos',
                    'installedFiles': [dst],
                    'installedPath': dst
                })
                logger.log(f"kernelua: Installed {dst}")
            except Exception as e:
                self._set_download_state(appid, {'status': 'failed', 'error': f'Install failed: {str(e)}'})
                logger.error(f"kernelua: install failed for {appid}: {e}")

        except Exception as e:
            logger.error(f"kernelua: backend download failed: {repr(e)}")
            self._set_download_state(appid, {'status': 'failed', 'error': f'Backend error: {str(e)}'})

    def add_via_lua(self, appid: int, endpoints: Optional[List[str]] = None) -> Dict[str, Any]:
        try: appid = int(appid)
        except (ValueError, TypeError):
            return {'success': False, 'error': 'Invalid appid'}

        self._set_download_state(appid, {'status': 'queued', 'bytesRead': 0, 'totalBytes': 0})

        def run():
            try:
                self._download_backend(appid)
            except Exception as e:
                logger.error(f"kernelua: unhandled error: {e}")
                self._set_download_state(appid, {'status': 'failed', 'error': f'Crash: {str(e)}'})

        threading.Thread(target=run, daemon=True).start()
        return {'success': True}

    def remove_via_lua(self, appid: int) -> Dict[str, Any]:
        try: appid = int(appid)
        except (ValueError, TypeError):
            return {'success': False, 'error': 'Invalid appid'}

        try:
            stplug = get_stplug_in_path()
            removed = []
            lua_file = os.path.join(stplug, f'{appid}.lua')
            if os.path.exists(lua_file):
                os.remove(lua_file); removed.append(f'{appid}.lua')
            disabled = os.path.join(stplug, f'{appid}.lua.disabled')
            if os.path.exists(disabled):
                os.remove(disabled); removed.append(f'{appid}.lua.disabled')
            for name in os.listdir(stplug):
                if name.startswith(f'{appid}_') and name.endswith('.manifest'):
                    os.remove(os.path.join(stplug, name)); removed.append(name)
            if removed:
                logger.log(f"kernelua: Removed {removed}")
                return {'success': True, 'message': f'Removed {len(removed)} files', 'removed_files': removed}
            return {'success': False, 'error': f'No files found for app {appid}'}
        except Exception as e:
            logger.error(f"kernelua: remove error for {appid}: {e}")
            return {'success': False, 'error': str(e)}
